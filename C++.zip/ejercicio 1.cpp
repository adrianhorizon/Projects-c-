#include <cstdlib>
#include <iostream>
  
using namespace std;
  
int main()
{
 int num;
  
  cout<<"Escriba un numero: ";
  cin>>num;
  
  if(num%2==0)
  {
   cout<<"El numero es par\n"<<endl;
        }
    else
    {
     cout<<"El numero no es par\n"<<endl;
     }
     system("PAUSE");
     return 0;
}

#include<iostream>
#include<cstdlib>
 
using namespace std;
 
int main ()
{
    int edad;
    cout<<"Digite su edad:";
    cin>>edad;
    
    if(edad>18)
    {
               cout<<"Es mayor de edad\n"<<endl;
               }
               else
               cout<<"No es mayor de edad\n"<<endl;
               
               system("PAUSE");
               return 0;
     
}
